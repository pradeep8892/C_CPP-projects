#include <iostream>
#include <string>
using namespace std;
class INDIA{
  public:
  int no_of_states;
  std::string capital;
  int rank_population;
  std::string prime_minister;
};

struct BHARAT{
  int no_of_states;
  std::string capital;
  int rank_population;
  std::string prime_minister;
};
class ABC{
   
    
};
class C { 
        char c; 
        int int1; 
        int int2; 
        int i; 
        long l; 
        short s; 
        string abc{"hi i am here this anmsmdf  "};
}; 
int main()
{

    cout<<"Size of class (ABC): "<< sizeof(ABC)<<endl;
    cout<<"Size of class (C):  "<< sizeof(C)<<endl;

    return 0;
}
